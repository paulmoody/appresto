Shopping Mall
======================

A pleasant looking shopping cart written in BackboneJS and jQuery

The css code in compiled starting from a LESS file.

You can clone/download the code, everything in in the repo except for the bootstrap's file and jQuery: they are taken from their CDN.

All images are taken from [Unsplash](http://www.unsplash.com)